This issue tracker is only for reporting bugs (suggesting features) for the plugin itself.

Please **do not** ask support questions for configuring / using a particular engine/library for PDF generation.
Use one of CakePHP's or the particular engine/library's support forum for that.